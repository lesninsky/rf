<?php
	global $pagenow;
	
	if(file_exists(get_theme_root().'/runway-framework/framework/load.php') && $pagenow !== 'customize.php' && !isset($_REQUEST['wp_customize'])){
		require_once(get_theme_root().'/runway-framework/framework/load.php');

		// include extension
		require_once(dirname(__FILE__).'/plugin-installer/load.php');
	}
?>