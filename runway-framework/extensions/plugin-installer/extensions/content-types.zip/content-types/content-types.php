<?php 
/*
Plugin Name: Content types
Description: Content types
*/
			
global $shortname;

if ($shortname === '' || $shortname == null) {
	$themeTitle = wp_get_theme();
	$shortname = apply_filters('shortname', sanitize_title($themeTitle . '_'));
}
$current_extensions = get_option($shortname . 'extensions-manager');
$theme_name = preg_replace('/_$/', '', $shortname);
$is_child = (!file_exists(get_stylesheet_directory().'/framework/'))? true : false;
	
if ($current_extensions == false || ($current_extensions != false && isset($current_extensions['extensions'][$theme_name]) && !in_array('content-types/load.php', $current_extensions['extensions'][$theme_name]['active']))) {
	require_once(dirname(__FILE__) . '/load-extension.php');
} else {

	if($is_child) {
		function content_types_error_notice() {
			?>
			<div class='error'>
				<p><?php _e('The "Content types"  plugin cannot work, as the "Content types" extension already works. Please switch off the extension to have the plugin work'); ?></p>
			</div>
			<?php
		}

		add_action('admin_notices', 'content_types_error_notice');
	}
}
?>