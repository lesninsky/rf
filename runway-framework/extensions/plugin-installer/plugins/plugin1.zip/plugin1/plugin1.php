<?php 
/*
Plugin Name: Sample - Plugin 1
Plugin URI:
Description: Just an example plugin file for testing and development. This does nothing.
Author: Parallelus
Version: 1.1
Author URI: 
*/



?>